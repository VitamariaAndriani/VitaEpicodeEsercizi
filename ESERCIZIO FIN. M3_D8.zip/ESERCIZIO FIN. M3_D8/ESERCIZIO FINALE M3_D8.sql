-- Esercizio_Finale M3-D8;
-- Traccia_esercizio

-- CANDIDATO (codice, cognome, nome, via_residenza, cap_residenza, citta_residenza, data_di_nascita, luogo_nascita) 
-- TELEFONO (numero_telefono, candidato) 
-- TITOLO_STUDIO (codice, descrizione) 
-- ISTRUZIONE (candidato, titolo_studio, data_titolo_studio, voto, istituto) 
-- ATTIVITA (codice, mansione) 
-- ESPERIENZA (candidato, attivita, data_inizio, data_fine, );

create database Lavoro;
use Lavoro;

create table Candidato (
Codice varchar(255),
Cognome_candidato varchar(50),
nome_candidato varchar (100),
via_residenza varchar(100),
cap_residenza varchar(30),
città_residenza varchar(50),
data_di_nascita date not null,
luogo_nascita varchar(100),
	primary key(Codice));
    
insert into Candidato 
values ('1234','Andriani','Vita','via Alcide da Gapseri','74123','Bari','1992-05-04','Taranto'),
	   ('1235','Altamura','Giuseppe','via Bruno Buozzi','70122','Torino','1993-05-03','Roma'),
	   ('1236','Bianchi','Mario','via Giuseppe Mazzini','02120','Bologna','1995-02-01','Bologna'),
       ('1237','Bolognese','Mara','via Giovanni Verga','50021','Milano','1996-12-04','Trieste'),
       ('1238','Vessa','Giovanni','via Giacomo Leopardi','20123','Roma','1994-02-03','Palermo');
       
create table Telefono (
numero_telefono varchar(100),
candidato varchar(255),
		primary key (numero_telefono),
        foreign key (candidato) references Candidato(codice));
	
insert into Telefono
values ('366-5348229','1234'),
       ('348-2286954','1235'),
       ('351-2536569','1236'),
       ('325-3632569','1237'),
       ('366-7845965','1238');
       
create table Titolo_studio (
codice varchar(255),
descrizione varchar(255),
	primary key (codice));
    
insert into Titolo_Studio 
values ('255','Diploma'),
       ('256','Laurea'),
       ('257','Diploma'),
       ('258','Laurea'),
       ('259','Dipoma');

create table Istruzione (
candidato varchar(255),
titolo_studio varchar(255),
data date not null,
voto decimal(4,2),
istituto varchar(255),
     primary key (candidato,titolo_studio),
     FOREIGN KEY (titolo_studio) REFERENCES Titolo_Studio(codice));
     
insert into Istruzione
values ('1234', '255', '2007-04-03', 60.00, 'Galasso'),
       ('1235', '256', '2012-06-15', 85.50, 'Università di Bari'),
       ('1236', '257', '2015-09-22', 92.75, 'Politecnico di Torino'),
       ('1237', '258', '2004-07-12', 70.25, 'Scuola Media "G. Pascoli'),
       ('1238', '259', '2006-05-28', 78.00, 'Liceo Classico "A. Manzoni');

       
create table Attività (
codice_attività varchar(100),
mansione varchar(100),
primary key (codice_attività));

insert into Attività 
values ('A001', 'Analista di dati'),
	   ('A002', 'Sviluppatore software'),
       ('A003', 'Project manager'),
       ('A004', 'Designer grafico'),
       ('A005', 'Ingegnere civile');
       
CREATE TABLE Esperienza (
  candidato varchar(255),
  attività VARCHAR(100),
  data_inizio DATE,
  data_fine DATE,
  primary key (candidato, attività),
  foreign key (candidato) references istruzione(candidato),
  foreign key (attività) references Attività(codice_attività));
  
INSERT INTO Esperienza
VALUES ('1234','A001','2022-01-15','2022-12-31'),
       ('1235','A002','2021-03-10','2022-01-14'),
       ('1236','A003', '2022-05-20','2022-11-30'),
	   ('1237','A004', '2022-02-01','2022-09-30'),
       ('1238','A005', '2022-06-15','2022-12-15');
       
-- Almeno 10 interrogazioni a piacere 
-- 1. Il numero dei candidati che risiedono a 'Bologna'
-- 2. Trova il numero dei candiati che abbiamo come titilo_studio la 'Laurea'
-- 3. Trova il candidato che abbia una maggiore età di 22 anni
-- 4. Per ogni candidato calcolare la media dei voti maggiore di 75
-- 5. I candidati che si sono Diplomati nel 2006
-- 6. Visualizzare per ogni candidato il codice, l'attività e la data di nascita
-- 7. Visualizzare l'anno di nascita di ogni canidato 
-- 8. Trova i candidati che hanno una esperienza compatibile con una mansione rihiesta
-- 9. Visualizzare la data di inzio esperienza dei candidati nel formato YYYY-MM-DD
-- 10. Trovare il nome dei candidati che iniziano con la lettera 'M'


-- Interrogazione numero 1. Il numero dei candidati che risiedono a 'Bologna'
SELECT COUNT(*) AS Numero_Candidati_Bologna
FROM Candidato
WHERE città_residenza = 'Bologna';

-- Interrogazione numero 2. Trova il numero dei candiati che abbiamo come titilo_studio la 'Laurea'
SELECT COUNT(*) AS Numero_di_candidati
FROM titolo_studio
WHERE descrizione = 'Laurea';

-- Interrogazione numero 3. Trova il candidato che abbia una maggiore età di 22 anni
SELECT Codice, Cognome_candidato, nome_candidato, data_di_nascita
FROM Candidato
WHERE DATEDIFF(CURRENT_DATE(),data_di_nascita)>22
ORDER BY data_di_nascita ;

-- Interrogazione nuemero 4. Per ogni candidato calcolare la media dei voti maggiore di 75
SELECT candidato, AVG(voto) AS Media_Voti
FROM Istruzione
WHERE voto>75
GROUP BY candidato;

-- Interrogazione numero 5. I candidati che si sono Diplomati nel 2006
SELECT c.Codice, c.Cognome_candidato, c.nome_candidato
FROM Candidato c
INNER JOIN Istruzione i ON c.Codice = i.candidato
WHERE i.titolo_studio = '259' -- Diploma
  AND YEAR(i.data) = 2006;

-- Interrogazione numero 6. Visualizzare per ogni candidato il codice,
-- ,l'attività e la data di nascita
SELECT c.Codice, a.mansione AS Attività, c.data_di_nascita AS Data_di_Nascita
FROM Candidato c
INNER JOIN Esperienza e ON c.Codice = e.candidato
INNER JOIN Attività a ON e.attività = a.codice_attività
ORDER BY c.Codice;

-- Interrogazione numero 7. Visualizzare l'anno di nascita di ogni canidato
SELECT Codice, Cognome_candidato, nome_candidato, YEAR(data_di_nascita) AS Anno_Nascita
FROM Candidato;

-- Interrogazione numero 8. Trova i candidati che hanno una esperienza compatibile con una mansione rihiesta
SELECT c.Codice, c.Cognome_candidato, c.nome_candidato
FROM Candidato c
INNER JOIN Esperienza e ON c.Codice = e.candidato
INNER JOIN Attività a ON e.attività = a.codice_attività
WHERE a.mansione = 'Sviluppatore software';


-- Interrogazione numero 9. Visualizzare la data di inzio esperienza dei candidati nel formato YYYY-MM-DD
SELECT candidato, attività, DATE_FORMAT(data_inizio, '%Y-%m-%d') AS Data_Inizio_Esperienza
FROM Esperienza;

-- Interrogazione numero 10. Trovare il nome dei candidati che iniziano con la lettera 'M'
SELECT Candidato.nome_candidato 
FROM Candidato
WHERE nome_candidato LIKE 'M%';